﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Sofrecom
{
	class Program
	{
	
		static void Main(string[] args)
		{
			var teclado = new List<Tecla>();
			teclado.Add(new Tecla { Numero = 0, Letras = new List<char> { ' '} });
			teclado.Add(new Tecla { Numero = 2, Letras = new List<char> { 'a', 'b', 'c' } });
			teclado.Add(new Tecla { Numero = 3, Letras = new List<char> { 'd', 'e', 'f' } });
			teclado.Add(new Tecla { Numero = 4, Letras = new List<char> { 'g', 'h', 'i' } });
			teclado.Add(new Tecla { Numero = 5, Letras = new List<char> { 'j', 'k', 'l' } });
			teclado.Add(new Tecla { Numero = 6, Letras = new List<char> { 'm', 'n', 'o' } });
			teclado.Add(new Tecla { Numero = 7, Letras = new List<char> { 'p', 'q', 'r', 's' } });
			teclado.Add(new Tecla { Numero = 8, Letras = new List<char> { 't', 'u', 'v' } });
			teclado.Add(new Tecla { Numero = 9, Letras = new List<char> { 'w', 'x', 'y', 'z' } });

			Console.WriteLine("Escribi una frase:  "); 
			var frase = Console.ReadLine();
			string resultado = string.Empty;
			int numeroAnterior = 0;
			foreach (var letra in frase.ToCharArray())
			{
				var tecla = teclado.Where(t => t.Letras.Contains(letra)).FirstOrDefault();

				if (numeroAnterior == tecla.Numero)
				{
					resultado += " ";
				}
				else
				{
					numeroAnterior = tecla.Numero;
				}

				var index = tecla.Letras.FindIndex(l => l == letra);
				for (int i = 0; i < (index + 1); i++)
				{
					resultado += tecla.Numero.ToString();
				}
				
				

				

			}
			Console.WriteLine(resultado);

		}
	}
	class Tecla
	{
		public  List<char> Letras { get; set; }
		public int Numero { get; set; }
	}
}
